import base64
import json
import boto3
import uuid
import re
import sys
import psycopg2
import os.path as path
from enum import Enum
from ast import literal_eval
from datetime import datetime
from pathlib import Path
#from c360.tokenization.tokens import Tokenizer
from rfernet import Fernet as rFernet

lib_folder = Path(__file__).parent / "lib"
sys.path.insert(0, str(lib_folder))
from aws_lambda_powertools import Metrics
from aws_lambda_powertools.metrics import MetricUnit
from aws_lambda_powertools.utilities.typing import LambdaContext

dynamo_client = boto3.client('dynamodb', region_name='us-west-2')
sm_client = boto3.client('secretsmanager', region_name='us-west-2')
s3 = boto3.resource('s3', region_name='us-west-2')
SECRETS_TABLE = "sc_ww360_enc"
RDS = "stellarbi/rds"
BUCKET = "s3-stellar-stream"
today = datetime.now().strftime("%y-%m-%d")
#T = Tokenizer()


class CErrorTypes(Enum):
    ENCRYPTION = 0
    NEW_SCHEMA = 1
    NEW_TABLE = 2
    NEW_COLUMNS = 3
    SCHEMA_DEFINITION = 4
    QUERY = 5


class Schema:
    def __init__(self, file_name: str):
        self.file_name = file_name
        self.file_location = f'/tmp/{self.file_name}'
        self._download_file()
        self._read_data()

    def _download_file(self):
        s3.Bucket(BUCKET).download_file(
            f'schema/{self.file_name}', self.file_location)
        return

    def _read_data(self):
        file_name = path.join(path.dirname(
            path.abspath(__file__)), self.file_location)
        with open(file_name, 'r') as myfile:
            self.data = json.loads(myfile.read())

    def _write_to_data(self):
        file_name = f'schema/{self.file_name}'
        s3object = s3.Object(BUCKET, file_name)
        s3object.put(
            Body=(bytes(json.dumps(self.data).encode('UTF-8')))
        )


def retrieve_rfernet_keys(dynamo_client, table_name):
    results = dynamo_client.get_item(
        TableName=table_name,
        Key={
            'token': {'S': 'rfernet_magento'}
        }
    )
    return results['Item']['data']['S']


def db_conn(pg_credential):
    return psycopg2.connect(host=pg_credential.get('host'),
                            port=pg_credential.get('port'),
                            user=pg_credential.get('username'),
                            password=pg_credential.get('password'),
                            database=pg_credential.get('dbname'))


pg_credentials = json.loads(
    sm_client.get_secret_value(SecretId=RDS)['SecretString'])
metrics = Metrics(namespace="StellarStreaming")
rfernet_keys = retrieve_rfernet_keys(dynamo_client, SECRETS_TABLE)
r_fernet = rFernet(rfernet_keys)


def decrypt_record(record: bytes):
    decrypted_record = None
    try:
        decrypted_record = json.loads(r_fernet.decrypt(record))
    except Exception as exp:
        pass
    return decrypted_record


def run_query(query: str, event: bytes):
    conn = db_conn(pg_credentials)
    cur = conn.cursor()
    try:
        cur.execute(query)
        resp = True
    except:
        metrics.add_metadata(
            key='query-error', value=f"query: {query} record: {event}")
        resp = None
    conn.commit()
    cur.close()
    conn.close()
    return resp


db_schemas = Schema('db_schemas.json')
db_tables = Schema('db_tables.json')


class ParseRecord:
    def __init__(self, record: bytes, event: bytes):
        self.event = event
        self.record = base64.b64decode(
            record['kinesis']['data']).decode('utf-8')
        self.new_columns = []
        self.process()

    def _send_record_to_s3(self, error: CErrorTypes):
        if error == error.NEW_SCHEMA:
            location = 'error/new_schema'
        elif error == error.NEW_TABLE:
            location = 'error/new_table'
        elif error == error.NEW_COLUMNS:
            location = 'error/new_columns'
        elif error == error.SCHEMA_DEFINITION:
            location = 'error/unknown'
        elif error == error.QUERY:
            location = 'error/query'
        file_name = f'{location}/{self.table}/{self.schema}/{today}_{uuid.uuid4().hex}.json'
        s3object = s3.Object(BUCKET, file_name)
        s3object.put(
            Body=(bytes(json.dumps(self.record).encode('UTF-8')))
        )
        metrics.add_metadata(key='error', value=location)
        return

    def _record_type(self):
        if isinstance(self.record, str):
            self.record = json.loads(self.record)
        record_type = self.record['type']
        if record_type == 'WriteRowsEvent':
            self.type = 'write'
            self.values = self.record['row']['values']
        elif record_type == 'DeleteRowsEvent':
            self.type = 'delete'
            self.values = self.record['row']['values']
        elif record_type == 'UpdateRowsEvent':
            self.type = 'write'
            self.values = self.record['row']['after_values']
        self.schema = self.record['schema']
        self.table = self.record['table']
        self.primary_key = db_tables.data[self.table]['primary_key']
        return

    def _identify_pii(self, col):
        # Email case
        value = self.values[col]
        if len(re.findall("([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)", value)) > 0:
            db_tables.data[self.table]['columns'].update({col: 'email'})
        return

    def _dtype(self, col):
        value = self.values[col]
        if not value:
            return 'NULL'
        if str(value) in ['NULL', '0000-00-00 00:00:00', 'None']:
            return 'NULL'
        if isinstance(value, str):
            return 'str'
        value = str(value)
        try:
            dtype = type(literal_eval(value))
        except (ValueError, SyntaxError):
            dtype = str
        if dtype == str:
            return 'str'
        elif dtype == float:
            return 'float'
        elif dtype == int:
            return 'int'
        return 'NULL'

    def _validate_data(self):
        if not db_schemas.data.get(self.schema):
            self._send_record_to_s3(CErrorTypes.NEW_SCHEMA)
            return

        if not db_tables.data.get(self.table):
            self._send_record_to_s3(CErrorTypes.NEW_TABLE)
            return

        for col in self.values.keys():
            if not db_tables.data[self.table]['columns'].get(col):
                dtype = self._dtype(col)
                if dtype == 'NULL':
                    continue
                self.new_columns.append((col, dtype))
        return True

    def _modify_postgres_build_query(self, dtype: str):
        ctype = None
        if dtype == 'int':
            ctype = 'integer'
        elif dtype == 'float':
            ctype = 'numeric(20,4)'
        elif dtype == 'str':
            ctype = 'character varying(255)'
        return ctype

    def _modify_postgres(self):
        dquery = ''
        for cols in self.new_columns:
            col = cols[0]
            if cols[1] == 'NULL':
                del self.values[col]
                continue
            dtype = self._modify_postgres_build_query(cols[1])
            dquery += f' ADD COLUMN {col} {dtype} ,'
        dquery = dquery[:-1]
        for country in db_schemas.data:
            query = f"ALTER Table main.{country}.{self.table} {dquery}"
            run_query(query, self.event)
        return

    def _modify_dtable(self):
        for cols in self.new_columns:
            if not self.values.get(cols[0]):
                continue
            col = cols[0]
            value = self.values[cols[0]]
            dtype = cols[1]
            db_tables.data[self.table]['columns'].update({col: True})
            # Pii data
            if dtype == 'str':
                self._identify_pii(col)
        db_tables._write_to_data()
        return

    def _modify_schema(self):
        self._modify_postgres()
        self._modify_dtable()

    def _generate_delete_query(self):
        new_filter = ''
        for col in self.primary_key:
            if isinstance(self.values[col], int):
                primary_key_value = f"{col} = {self.values[col]} AND "
            else:
                primary_key_value = f"{col} = '{self.values[col]}' AND "
            new_filter += primary_key_value
        new_filter = new_filter[:-5]
        query = f"DELETE FROM main.{self.schema}.{self.table} WHERE {new_filter}"
        query = run_query(query, self.event)
        if not query:
            self._send_record_to_s3(CErrorTypes.QUERY)
            return
        return True

    def _validate_insert(self, value):
        if str(value) in ['NULL', '0000-00-00 00:00:00', 'None']:
            return
        return True

    def _generate_insert_query(self):
        fields = []
        values = []
        for k, v in self.values.items():
            if  v is None:
                continue
            if isinstance(v, str):
                v = v.replace("\n", " ")
                v = v.replace("'", '"')
            fields.append(k)
            if isinstance(db_tables.data[self.table]["columns"][k], str):
                v = T.tokens(
                    [v], data_class=db_tables.data[self.table]["columns"][k])[0]
            values.append(v)
        values = tuple(values)
        fields = f"{fields}".replace(
            "[", "").replace("]", "").replace("'", "")
        query = f'insert into main.{self.schema}.{self.table} ({fields}) values {values}'
        query = run_query(query, self.event)
        if not query:
            self._send_record_to_s3(CErrorTypes.QUERY)
            return
        return True

    def process(self):
        # Encrypted records come from magento
        new_record = decrypt_record(self.record)
        if new_record:
            self.record = new_record
        self._record_type()
        if not self.type:
            self._send_record_to_s3(CErrorTypes.SCHEMA_DEFINITION)
            return
        if not self._validate_data():
            return
        # Process new columns
        if len(self.new_columns) > 0:
            self._modify_schema()
        if not self._generate_delete_query():
            return
        if self.type == 'delete':
            return
        if not self._generate_insert_query():
            return
        #metrics.add_metadata(key='schema', value=self.schema)
        #metrics.add_metadata(key='table', value=self.table)
        #metrics.add_metadata(key='type', value=self.type)
        #metrics.add_metric(name='TableMapped', unit=MetricUnit.Count, value=1)
        return


#@metrics.log_metrics
def handler(event, context: LambdaContext):
    for record in event.get('Records'):
        ParseRecord(record, event)
    return
